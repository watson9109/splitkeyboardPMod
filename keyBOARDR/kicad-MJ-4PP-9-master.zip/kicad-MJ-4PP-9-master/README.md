
# MJ-4PP-9 symbol & footprint library for KiCad

3.5 mm 4 pole mini jack

- [http://akizukidenshi.com/download/ds/avvicon/MJ-4PP-9.pdf](http://akizukidenshi.com/download/ds/avvicon/MJ-4PP-9.pdf)

![symbol](https://raw.githubusercontent.com/yskoht/kicad-MJ-4PP-9/images/symbol.png)

![footprint](https://raw.githubusercontent.com/yskoht/kicad-MJ-4PP-9/images/footprint.png)

## License

This software is released under the MIT License, see LICENSE.

